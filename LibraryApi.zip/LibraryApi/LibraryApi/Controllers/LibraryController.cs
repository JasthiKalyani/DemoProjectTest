﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.Extensions.Configuration;
using System.Web.Http.Cors;
using Domain.Entities;
using Domain.Interface;


namespace LibraryApi.Controllers
{
    [EnableCors(origins: "*", headers: "*", methods: "*", exposedHeaders: "X-Custom-Header")]
    [Route("api/[controller]")]
    [ApiController]
    public class LibraryController : Controller
    {
        //public IActionResult Index()
        //{
        //    return View();
        //}
        private readonly ILibrarydata _librarydata;

        
        public LibraryController(ILibrarydata librarydata)
        {
            _librarydata = librarydata;
        }
        [HttpGet]
        [Route("users/{id}")]
        public IActionResult GetUsers([FromQuery] int id)
        {
            var users = _librarydata.Users.GetUsers(id);
            return Ok(users);

        }
        [HttpPost]
        [Route("PostUser")]
        void Add(Users entity)
        {
            _librarydata.Users.Add(entity);
        }
    }
}
